package application;

import java.io.IOException;
import java.net.Socket;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
	public static final int Port = 8989;

	@Override
	public void start(Stage primaryStage) {
		try {

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MyServer.fxml"));
			Parent root = fxmlLoader.load();
			ServerController controller = fxmlLoader.getController();
			primaryStage.setResizable(false);
			controller.setStage(primaryStage);
			controller.init();
			primaryStage.setTitle("My Application");
			primaryStage.setScene(new Scene(root));

			Server sever = new Server(controller);
			primaryStage.setOnCloseRequest((e) -> {
				sever.ifExit = true;
				try (Socket socket = new Socket("127.0.0.1", Port)) {
					socket.close();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			});

			primaryStage.show();
			sever.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
