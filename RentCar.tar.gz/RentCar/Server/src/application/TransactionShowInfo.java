package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

//事物表格的一行
//对应的类的封装
public class TransactionShowInfo {
	private StringProperty ReUserIn;

	private StringProperty ReUsrTypeIn;

	private StringProperty ReOpTypeIn;

	private StringProperty ReOpTimeIn;

	private StringProperty ReOpResIn;

	public void setReUserIn(String value) {
		ReUserInProperty().set(value);
	}

	public String getReUserIn() {
		return ReUserInProperty().get();
	}

	public StringProperty ReUserInProperty() {
		if (ReUserIn == null) {
			ReUserIn = new SimpleStringProperty(this, "ReUserIn");
		}
		return ReUserIn;
	}

	public void setReUsrTypeIn(String value) {
		ReUsrTypeInProperty().set(value);
	}

	public String getReUsrTypeIn() {
		return ReUsrTypeInProperty().get();
	}

	public StringProperty ReUsrTypeInProperty() {
		if (ReUsrTypeIn == null) {
			ReUsrTypeIn = new SimpleStringProperty(this, "ReUsrTypeIn");
		}
		return ReUsrTypeIn;
	}

	public void setReOpTypeIn(String value) {
		ReOpTypeInProperty().set(value);
	}

	public String getReOpTypeIn() {
		return ReOpTypeInProperty().get();
	}

	public StringProperty ReOpTypeInProperty() {
		if (ReOpTypeIn == null) {
			ReOpTypeIn = new SimpleStringProperty(this, "ReOpTypeIn");
		}
		return ReOpTypeIn;
	}

	public void setReOpTimeIn(String value) {
		ReOpTimeInProperty().set(value);
	}

	public String getReOpTimeIn() {
		return ReOpTimeInProperty().get();
	}

	public StringProperty ReOpTimeInProperty() {
		if (ReOpTimeIn == null) {
			ReOpTimeIn = new SimpleStringProperty(this, "ReOpTimeIn");
		}
		return ReOpTimeIn;
	}

	public void setReOpResIn(String value) {
		ReOpResInProperty().set(value);
	}

	public String getReOpResIn() {
		return ReOpResInProperty().get();
	}

	public StringProperty ReOpResInProperty() {
		if (ReOpResIn == null) {
			ReOpResIn = new SimpleStringProperty(this, "ReOpResIn");
		}
		return ReOpResIn;
	}
}
