package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JOptionPane;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ServerController {
	@FXML
	private Tab tabRecord;
	@FXML
	private TableView<TransactionShowInfo> reTable;
	@FXML
	private TableColumn<TransactionShowInfo, String> ReUser;
	@FXML
	private TableColumn<TransactionShowInfo, String> ReUsrType;
	@FXML
	private TableColumn<TransactionShowInfo, String> ReOpType;
	@FXML
	private TableColumn<TransactionShowInfo, String> ReOpTime;
	@FXML
	private TableColumn<TransactionShowInfo, String> ReOpRes;
	@FXML
	private Tab tabEmployee;
	@FXML
	private ComboBox<String> EmCbQuery;
	@FXML
	private TextField EmTfCondition;
	@FXML
	private Button EmBtUpdate;
	@FXML
	private ComboBox<String> EnCbQuery;
	@FXML
	private TextField EnTfCondition;
	@FXML
	private Button EnBtUpdate;
	@FXML
	private TableView<StaffShowInfo> emTable;
	@FXML
	private TableColumn<StaffShowInfo, String> StEid;
	@FXML
	private TableColumn<StaffShowInfo, String> StName;
	@FXML
	private TableColumn<StaffShowInfo, String> StNum;
	@FXML
	private TableColumn<StaffShowInfo, String> StTotal;
	@FXML
	private Tab tabEnterprise;
	@FXML
	private TableView<RentShowInfo> enTable;
	@FXML
	private TableColumn<RentShowInfo, String> EmRTid;
	@FXML
	private TableColumn<RentShowInfo, String> EmUName;
	@FXML
	private TableColumn<RentShowInfo, String> EmEName;
	@FXML
	private TableColumn<RentShowInfo, String> EmCid;
	@FXML
	private TableColumn<RentShowInfo, String> EmOutTime;
	@FXML
	private TableColumn<RentShowInfo, String> EmBackTime;
	@FXML
	private TableColumn<RentShowInfo, String> EmExp;
	@FXML
	private Tab tabSetting;
	@FXML
	private TextField tfTimeStart;
	@FXML
	private TextField tfTimeEnd;
	@FXML
	private Button btSave;
	@FXML
	private Button btReset;

	@FXML
	private Button btClearTrans;

	private Stage stage;

	private String stTime;
	private String endTime;

	public void init() {

		// 控件列绑定到类的不同的属性上
		ReUser.setCellValueFactory(new PropertyValueFactory<>("ReUserIn"));
		ReUsrType.setCellValueFactory(new PropertyValueFactory<>("ReUsrTypeIn"));
		ReOpType.setCellValueFactory(new PropertyValueFactory<>("ReOpTypeIn"));
		ReOpTime.setCellValueFactory(new PropertyValueFactory<>("ReOpTimeIn"));
		ReOpRes.setCellValueFactory(new PropertyValueFactory<>("ReOpResIn"));

		StEid.setCellValueFactory(new PropertyValueFactory<>("StEidIn"));
		StName.setCellValueFactory(new PropertyValueFactory<>("StNameIn"));
		StNum.setCellValueFactory(new PropertyValueFactory<>("StNumIn"));
		StTotal.setCellValueFactory(new PropertyValueFactory<>("StTotalIn"));

		EmRTid.setCellValueFactory(new PropertyValueFactory<>("EmRTidIn"));
		EmUName.setCellValueFactory(new PropertyValueFactory<>("EmUNameIn"));
		EmEName.setCellValueFactory(new PropertyValueFactory<>("EmENameIn"));
		EmCid.setCellValueFactory(new PropertyValueFactory<>("EmCidIn"));
		EmOutTime.setCellValueFactory(new PropertyValueFactory<>("EmOutTimeIn"));
		EmBackTime.setCellValueFactory(new PropertyValueFactory<>("EmBackTimeIn"));
		EmExp.setCellValueFactory(new PropertyValueFactory<>("EmExpIn"));

		// 下拉条件框填充数据
		EmCbQuery.getItems()
				.addAll(new ArrayList<>(Arrays.asList("员工编号", "员工姓名", "经手数量小于", "经手数量大于", "收入合计小于", "收入合计大于", "无条件")));

		EnCbQuery.getItems()
				.addAll(new ArrayList<>(Arrays.asList("订单编号", "用户姓名", "员工姓名", "车牌号", "交易额大于", "交易额小于", "无条件")));

		// 时间范围设定为默认值
		btResetClicked(null);
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	// Event Listener on Button[#EmBtUpdate].onAction
	@FXML
	public void emBtUpdateClicked(Event event) {
		String query = "select RENT.E_ID,E_NAME,count(*) as QTY,sum(EXPENSE) as Total from RENT,EMPLOYEES ";
		// cbSelect值来自与下拉框,为条件选择
		String cbSelect = EmCbQuery.getValue();
		// condition值来自输入框,为更加详细的条件
		String condition = EmTfCondition.getText().trim();

		if (cbSelect == null) {
			cbSelect = "无条件";
		}
		switch (cbSelect) {
		case "员工编号":// 按员工编号模糊搜索
			query += "where RENT.E_ID = EMPLOYEES.E_ID and RENT.E_ID like '%" + condition + "%' and RT_TIME > " + stTime
					+ " and RT_TIME < " + endTime + " group by RENT.E_ID,E_NAME order by Total desc";
			break;
		case "员工姓名":// 按员工姓名搜索
			query += "where RENT.E_ID = EMPLOYEES.E_ID and E_NAME like '%" + condition + "%' and RT_TIME > " + stTime
					+ " and RT_TIME < " + endTime + " group by RENT.E_ID,E_NAME order by Total desc";
			break;
		case "经手数量小于":// 搜索经手数量小于condition的数据,这里不做输入类型安全检查
			if (condition.length() == 0) {
				JOptionPane.showMessageDialog(null, "输入条件,十进制数");
				return;
			}
			query += "where RENT.E_ID = EMPLOYEES.E_ID and RT_TIME > " + stTime + " and RT_TIME < " + endTime
					+ " group by RENT.E_ID,E_NAME having QTY < " + condition + " order by Total desc";
			break;
		case "经手数量大于":// 搜索经手数量小于condition的数据,这里不做输入类型安全检查
			if (condition.length() == 0) {
				JOptionPane.showMessageDialog(null, "输入条件,十进制数");
				return;
			}
			query += "where RENT.E_ID = EMPLOYEES.E_ID and RT_TIME > " + stTime + " and RT_TIME < " + endTime
					+ " group by RENT.E_ID,E_NAME having QTY > " + condition + " order by Total desc";
			break;
		case "收入合计小于":// 搜索收入合计小于condition的数据,这里不做输入类型安全检查
			if (condition.length() == 0) {
				JOptionPane.showMessageDialog(null, "输入条件,十进制数");
				return;
			}
			query += "where RENT.E_ID = EMPLOYEES.E_ID and RT_TIME > " + stTime + "and RT_TIME < " + endTime
					+ " group by RENT.E_ID,E_NAME having Total < " + condition + " order by Total desc";
			break;
		case "收入合计大于":// 搜索收入合计大于condition的数据,这里不做输入类型安全检查
			if (condition.length() == 0) {
				JOptionPane.showMessageDialog(null, "输入条件,十进制数");
				return;
			}
			query += "where RENT.E_ID = EMPLOYEES.E_ID and RT_TIME > " + stTime + "and RT_TIME < " + endTime
					+ " group by RENT.E_ID,E_NAME having Total > " + condition + " order by Total desc";
			break;
		case "无条件":
		default:// null
			query += "where RENT.E_ID = EMPLOYEES.E_ID and RT_TIME > " + stTime + "and RT_TIME < " + endTime
					+ " group by RENT.E_ID,E_NAME order by Total desc";
			break;
		}
		// 获取数据库的连接connection
		try (Connection connection = ConnectionDB.getConnection()) {
			// 获取查询结果集合resultSet
			ResultSet resultSet = connection.createStatement().executeQuery(query);
			ObservableList<StaffShowInfo> observableList = FXCollections.observableArrayList();
			while (resultSet.next()) {
				// 遍历resultSet结果集合中的每一行,构造成表格的一行进行展示
				StaffShowInfo staffShowInfo = new StaffShowInfo();
				staffShowInfo.setStEidIn(resultSet.getString("RENT.E_ID"));
				staffShowInfo.setStNameIn(resultSet.getString("E_NAME"));
				staffShowInfo.setStNumIn(resultSet.getString("QTY"));
				staffShowInfo.setStTotalIn(resultSet.getString("Total"));
				observableList.add(staffShowInfo);
			}
			// 将收集到的数据输入到表格进行展示
			emTable.setItems(observableList);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Event Listener on Button[#EnBtUpdate].onAction
	@FXML
	public void enBtUpdateClicked(Event event) {
		String query = "select RT_ID,U_NAME,E_NAME,C_ID,OUT_TIME,BACK_TIME,EXPENSE from RENT,USERS,EMPLOYEES "
				+ "where RENT.U_ID = USERS.U_ID and RENT.E_ID = EMPLOYEES.E_ID ";
		String cbSelect = EnCbQuery.getValue();
		String condition = EnTfCondition.getText().trim();

		if (cbSelect == null) {
			cbSelect = "无条件";
		}
		// "订单编号", "用户编号", "员工编号", "车牌号", "交易额大于", "交易额小于", "无条件"
		switch (cbSelect) {
		case "订单编号":
			query += "and RT_TIME > " + stTime + " and RT_TIME < " + endTime + " and RT_ID like '%" + condition
					+ "%' order by RT_ID";
			break;
		case "用户姓名":
			query += "and RT_TIME > " + stTime + " and RT_TIME < " + endTime + " and U_NAME like '%" + condition
					+ "%' order by U_NAME";
			break;
		case "员工姓名":
			query += "and RT_TIME > " + stTime + " and RT_TIME < " + endTime + " and E_NAME like '%" + condition
					+ "%' order by E_NAME";
			break;
		case "车牌号":
			query += "and RT_TIME > " + stTime + " and RT_TIME < " + endTime + " and C_ID like '%" + condition
					+ "%' order by C_ID";
			break;
		case "交易额大于":
			query += "and RT_TIME > " + stTime + " and RT_TIME < " + endTime + " and EXPENSE > " + condition;
			break;
		case "交易额小于":
			query += "and RT_TIME > " + stTime + " and RT_TIME < " + endTime + " and EXPENSE < " + condition;
			break;
		case "无条件":
		default:
			query += "and RT_TIME > " + stTime + " and RT_TIME < " + endTime;
			break;
		}
		try (Connection connection = ConnectionDB.getConnection()) {
			ResultSet resultSet = connection.createStatement().executeQuery(query);
			ObservableList<RentShowInfo> observableList = FXCollections.observableArrayList();
			while (resultSet.next()) {
				RentShowInfo rentShowInfo = new RentShowInfo();
				rentShowInfo.setEmRTidIn(resultSet.getString("RT_ID"));
				rentShowInfo.setEmUNameIn(resultSet.getString("U_NAME"));
				rentShowInfo.setEmENameIn(resultSet.getString("E_NAME"));
				rentShowInfo.setEmCidIn(resultSet.getString("C_ID"));
				rentShowInfo.setEmOutTimeIn(resultSet.getString("OUT_TIME"));
				Timestamp backTime = resultSet.getTimestamp("BACK_TIME");
				String back = backTime == null ? "未还车" : backTime.toString();
				rentShowInfo.setEmBackTimeIn(back);
				rentShowInfo.setEmExpIn(resultSet.getBigDecimal("EXPENSE") + "");
				observableList.add(rentShowInfo);
			}
			enTable.setItems(observableList);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Event Listener on Button[#btSave].onAction
	@FXML
	public void btSaveClicked(ActionEvent event) {
		String start = tfTimeStart.getText().trim();
		String end = tfTimeEnd.getText().trim();
		if (0 == start.length() && 0 == end.length()) {
			// 两个输入框都为空则代表恢复默认时间
			btResetClicked(null);
			JOptionPane.showMessageDialog(null, "已恢复默认时间");
			return;
		} else {
			try {
				if (0 != start.length()) {
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(start);
					// 开始时间设置为用户的输入时间
					stTime = "str_to_date('" + start + "','%Y-%m-%d %T')";
				} else {
					// 恢复默认开始时间,即本月初的时间
					stTime = "DATE_FORMAT(CURDATE(), '%Y-%m-01 00:00:00')";
				}
				if (0 != end.length()) {
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(end);
					// 结束时间设置为用户的输入时间
					endTime = "str_to_date('" + end + "','%Y-%m-%d %T')";
				} else {
					// 恢复默认结束时间,即当前时间
					endTime = "NOW()";
				}
				JOptionPane.showMessageDialog(null, "保存成功");
			} catch (ParseException e) {
				JOptionPane.showMessageDialog(null, "请检查时间格式是否正确");
			}
		}
	}

	// Event Listener on Button[#btReset].onAction
	@FXML
	public void btResetClicked(ActionEvent event) {
		// 默认查询当月累计数据
		stTime = "DATE_FORMAT(CURDATE(), '%Y-%m-01 00:00:00')";// 月初
		endTime = "NOW()";// 现在
		tfTimeStart.clear();// 输入框内容清空
		tfTimeEnd.clear();
	}

	@FXML
	public void btClearTransClicked(ActionEvent event) {
		// 事物表格清空
		System.out.println("clear");
		reTable.getItems().clear();
	}

	public synchronized void insertTransaction(TransactionShowInfo transactionShowInfo) {
		// 同步方法,为多个线程进行调用,最多同时一百条记录
		if (reTable.getItems().size() == 100) {
			reTable.getItems().remove(0);
		}
		reTable.getItems().add(transactionShowInfo);
	}

}
