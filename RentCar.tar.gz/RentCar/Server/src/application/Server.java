package application;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread {
	public volatile boolean ifExit = false;
	private final ServerController serverController;

	public Server(ServerController serverController) {
		this.serverController = serverController;
		// 图形界面控制器，传递到每个子线程中用以刷新用户的操作,
		// 即Server图形界面中事物记录表格,保证每个线程访问的controller的方法
		// 是同步的,即synchronized

	}

	@Override
	public void run() {
		try (ServerSocket serverSocket = new ServerSocket(Main.Port)) {
			Socket socket = null;
			while (true) {
				// 挂起等待客户端的socket连接
				socket = serverSocket.accept();
				// 等待图形界面关闭时触发ifExit赋值为假,
				// 且采用假连接方式使得accept函数返回,继续循环
				// 触发方式的设定在main函数中
				if (ifExit) {
					break;
				}
				// 创建新线程套接字监听客户端的数据
				Thread thread = new Thread(new ServerThread(socket, serverController));
				thread.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
