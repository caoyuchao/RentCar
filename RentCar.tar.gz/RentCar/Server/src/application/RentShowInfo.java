package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

//
public class RentShowInfo {

	private StringProperty EmRTidIn;

	private StringProperty EmUNameIn;

	private StringProperty EmENameIn;

	private StringProperty EmCidIn;

	private StringProperty EmOutTimeIn;

	private StringProperty EmBackTimeIn;

	private StringProperty EmExpIn;

	public void setEmExpIn(String value) {
		EmExpInProperty().set(value);
	}

	public String getEmExpIn() {
		return EmExpInProperty().get();
	}

	public StringProperty EmExpInProperty() {
		if (EmExpIn == null) {
			EmExpIn = new SimpleStringProperty(this, "EmExpIn");
		}
		return EmExpIn;
	}

	public void setEmBackTimeIn(String value) {
		EmBackTimeInProperty().set(value);
	}

	public String getEmBackTimeIn() {
		return EmBackTimeInProperty().get();
	}

	public StringProperty EmBackTimeInProperty() {
		if (EmBackTimeIn == null) {
			EmBackTimeIn = new SimpleStringProperty(this, "EmBackTimeIn");
		}
		return EmBackTimeIn;
	}

	public void setEmOutTimeIn(String value) {
		EmOutTimeInProperty().set(value);
	}

	public String getEmOutTimeIn() {
		return EmOutTimeInProperty().get();
	}

	public StringProperty EmOutTimeInProperty() {
		if (EmOutTimeIn == null) {
			EmOutTimeIn = new SimpleStringProperty(this, "EmOutTimeIn");
		}
		return EmOutTimeIn;
	}

	public void setEmCidIn(String value) {
		EmCidInProperty().set(value);
	}

	public String getEmCidIn() {
		return EmCidInProperty().get();
	}

	public StringProperty EmCidInProperty() {
		if (EmCidIn == null) {
			EmCidIn = new SimpleStringProperty(this, "EmCidIn");
		}
		return EmCidIn;
	}

	public void setEmRTidIn(String value) {
		EmRTidInProperty().set(value);
	}

	public String getEmRTidIn() {
		return EmRTidInProperty().get();
	}

	public StringProperty EmRTidInProperty() {
		if (EmRTidIn == null) {
			EmRTidIn = new SimpleStringProperty(this, "EmRTidIn");
		}
		return EmRTidIn;
	}

	public void setEmUNameIn(String value) {
		EmUNameInProperty().set(value);
	}

	public String getUNameIn() {
		return EmUNameInProperty().get();
	}

	public StringProperty EmUNameInProperty() {
		if (EmUNameIn == null) {
			EmUNameIn = new SimpleStringProperty(this, "EmUNameIn");
		}
		return EmUNameIn;
	}

	public void setEmENameIn(String value) {
		EmENameInProperty().set(value);
	}

	public String getEmENameIn() {
		return EmENameInProperty().get();
	}

	public StringProperty EmENameInProperty() {
		if (EmENameIn == null) {
			EmENameIn = new SimpleStringProperty(this, "EmENameIn");
		}
		return EmENameIn;
	}

}
