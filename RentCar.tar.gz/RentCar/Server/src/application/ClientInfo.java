package application;

import java.io.Serializable;

//同服务器端

//下订单，登陆后用ClientInfo与OperatorResult类的子类进行交互
class ClientInfo implements Serializable {
	String u_Id;
	String operator;
	String c_Id;
	String outTime;
	int intervalDays;

	public ClientInfo() {

	}

	public ClientInfo(String u_Id, String operator, String c_Id, String outTime, int intervalDays) {
		this.u_Id = u_Id;
		this.operator = operator;
		this.c_Id = c_Id;
		this.outTime = outTime;
		this.intervalDays = intervalDays;
	}
}

class EmployeeOp {

}

class OperatorResult implements Serializable {
	boolean ifSuccess;
	String descriptions;

	public OperatorResult() {

	}

	public OperatorResult(boolean ifSuccess, String descriptions) {
		this.ifSuccess = ifSuccess;
		this.descriptions = descriptions;
	}
}

// 客户端中用户和员工登陆以及客户端发送查看个人信息的请求
class Person implements Serializable {
	String u_Id;
	String password;
	String operator;

	public Person() {

	}

	public Person(String u_Id, String password, String operator) {
		// 登陆
		this.u_Id = u_Id;
		this.password = password;
		this.operator = operator;
	}

}

// 客户端中用户注册和找回密码和充值以及充值会员
class PersonClient extends Person implements Serializable {
	String name;
	String phoneNum;
	boolean ifVip;
	int rank;
	double balance;

	public PersonClient() {

	}

	public PersonClient(String u_Id, String password, String operator, String name, String phoneNum) {
		super(u_Id, password, operator);
		this.name = name;
		this.phoneNum = phoneNum;
	}
}

class UserInfo extends OperatorResult implements Serializable {
	public UserInfo() {

	}

	public UserInfo(boolean ifSuccess, String descriptions) {
		super(ifSuccess, descriptions);
	}

	PersonClient personClient;
}

class QueryCar implements Serializable {
	// queryType:仅仅支持按照价格范围来查找
	String u_Id;
	String queryType;
	double price;

	public QueryCar() {

	}

	public QueryCar(String u_Id, String queryType, double price) {
		this.u_Id = u_Id;
		this.queryType = queryType;
		this.price = price;
	}
}

class QueryCarDetails extends OperatorResult implements Serializable {

	public QueryCarDetails() {

	}

	public QueryCarDetails(boolean ifSuccess, String descriptions) {
		super(ifSuccess, descriptions);
	}

	QueryCarInfo[] queryCarInfos;
}

class QueryDeal implements Serializable {
	// queryType:所有记录,或者仅仅经手但未还车记录
	String e_Id;
	String queryType;

	public QueryDeal() {

	}

	public QueryDeal(String e_Id, String queryType) {
		this.e_Id = e_Id;
		this.queryType = queryType;
	}
}

class QueryDealDetails extends OperatorResult implements Serializable {
	public QueryDealDetails() {

	}

	public QueryDealDetails(boolean ifSuccess, String descriptions) {
		super(ifSuccess, descriptions);
	}

	QueryDealInfo[] queryDealInfos;
}

class QueryCarInfo implements Serializable {
	String c_Id;
	String c_Type;
	String c_description;
	double c_Price;
	double c_TimeOutPrice;
}

class QueryHistory implements Serializable {
	String u_Id;
	String queryType;

	public QueryHistory() {

	}

	public QueryHistory(String u_Id, String queryType) {
		this.u_Id = u_Id;
		this.queryType = queryType;
	}
}

class QueryHisBillDetails extends OperatorResult implements Serializable {
	public QueryHisBillDetails() {

	}

	public QueryHisBillDetails(boolean ifSuccess, String descriptions) {
		super(ifSuccess, descriptions);
	}

	QueryHisBillInfo[] queryHisBillInfos;
}

class QueryHisBillInfo implements Serializable {
	String rt_Id;
	String c_Id;
	String c_Type;
	String expense;
	String outTimeExp;
	String getCarTime;
	String interval;
	String e_Name;
	String progress;
}

class QueryDealInfo implements Serializable {
	String rt_Id;
	String u_Id;
	String u_Name;
	String c_Id;
	String outTime;
	String backTime;
	String process;
	String timeInterval;
}
