package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

public class ConnectionDB {
	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		try (BufferedReader bufferedReader = new BufferedReader(
				new InputStreamReader(new FileInputStream(new File("conf"))))) {
			// 从文件读取配置信息
			String url = bufferedReader.readLine();
			String user = bufferedReader.readLine();
			String password = bufferedReader.readLine();
			String driver = bufferedReader.readLine();
			if (url == null || user == null || password == null || driver == null) {
				return null;
			}
			Class.forName(driver);
			// 获取数据库的连接并返回
			return DriverManager.getConnection(url, user, password);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Timestamp getDBTime() throws SQLException, ClassNotFoundException {
		// 获取数据库的时间
		try (Connection connection = ConnectionDB.getConnection()) {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select CURRENT_TIMESTAMP() AS time");
			if (resultSet.next()) {
				Timestamp timestamp = resultSet.getTimestamp("time");
				return timestamp;
			} else {
				throw new SQLException();
			}
		}
	}

	// 回滚函数,已放弃使用
	public static void rollback(Connection connection) {
		try {
			if (connection != null) {
				connection.rollback();
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}