package application;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class ServerThread implements Runnable {
	Socket socket = null;// 和本线程相关的Socket
	private boolean ifExit = false;
	private final ServerController serverController;

	public ServerThread(Socket socket, ServerController serverController) {
		// socket用来和客户端socket连接通信
		this.socket = socket;
		// serverController用以在事物列表控件中插入信息,显示用户的操作
		this.serverController = serverController;
	}

	@Override
	public void run() {
		try {
			while (!ifExit) {
				// 根据相信的socket获取输出流
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
				// 将读到的对象数据进行处理后返回的处理结果写回客户端
				objectOutputStream
						.writeObject(processObject(new ObjectInputStream(socket.getInputStream()).readObject()));
				// 刷新流,立刻写回
				objectOutputStream.flush();
			}
		} catch (Exception e) {
			// 根据客户端的断开连接退出上述死循环
			ifExit = true;
		}
	}

	public Object processObject(Object object) {
		if (object instanceof Person) {
			// 客户端发送的对象是Person类型
			return processPerson((Person) object);
		} else if (object instanceof ClientInfo) {
			// 客户端发送的对象是ClientInfo类型
			return processClientInfo((ClientInfo) object);
		} else if (object instanceof QueryCar) {
			return processQueryCar((QueryCar) object);
		} else if (object instanceof QueryDeal) {
			return processQueryDeal((QueryDeal) object);
		} else if (object instanceof QueryHistory) {
			return processQueryHistory((QueryHistory) object);
		}
		// 异常类型
		return new OperatorResult(false, "数据传输异常");
	}

	public OperatorResult processClientInfo(ClientInfo clientInfo) {
		// 待完成
		return new OperatorResult();
	}

	public OperatorResult processPerson(Person person) {
		// 根据操作类型进行不同的处理
		switch (person.operator) {
		case "用户注册":
			return processUsrReg(person);
		case "用户登陆":
			return processUsrLogin(person);
		case "用户找回密码":
			return processUsrModiPassword(person);
		case "员工登陆":
			return processEmployeeLogin(person);
		case "用户信息查询":
			return processUsrInfo(person);
		case "用户充值":
			return processRecharge(person);
		default:
			return new OperatorResult(false, "不支持该类型性操作");
		}
	}

	public OperatorResult processUsrReg(Person person) {
		// 注册功能需要客户端发送的对象是PersonClient类型
		if (person instanceof PersonClient) {
			PersonClient personClient = (PersonClient) person;
			// 实例化一个事物记录,记录此条操作，默认失败
			TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
			transactionShowInfo.setReUserIn(personClient.u_Id);
			transactionShowInfo.setReUsrTypeIn("普通用户");
			transactionShowInfo.setReOpTypeIn(personClient.operator);
			transactionShowInfo.setReOpTimeIn("数据库异常");
			transactionShowInfo.setReOpResIn("失败");
			// Connection tmp = null;
			try (Connection connection = ConnectionDB.getConnection()) {
				// 获取操作的时间,时间统一来自数据库
				transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
				// tmp = connection;
				// 关闭自动提交
				connection.setAutoCommit(false);
				// 查询数据库中是否已经有该数据
				String query = "select U_ID from USERS where U_ID = '" + personClient.u_Id + "'";
				if (connection.createStatement().executeQuery(query).next()) {
					serverController.insertTransaction(transactionShowInfo);
					return new OperatorResult(false, "该用户已注册");
				}
				// 插入客户端传递的数据
				String insert = "insert into USERS values(?,?,?,?,?,?,?)";
				PreparedStatement preparedStatement = connection.prepareStatement(insert);
				preparedStatement.setString(1, personClient.u_Id);
				preparedStatement.setString(2, personClient.password);
				preparedStatement.setString(3, personClient.phoneNum);
				preparedStatement.setString(4, personClient.name);
				preparedStatement.setBoolean(5, personClient.ifVip);
				preparedStatement.setInt(6, personClient.rank);
				preparedStatement.setBigDecimal(7, new BigDecimal(personClient.balance));
				preparedStatement.executeUpdate();
				connection.commit();
				transactionShowInfo.setReOpResIn("成功");
				serverController.insertTransaction(transactionShowInfo);
				// 返回处理结果
				return new OperatorResult(true, "注册成功");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				// ConnectionDB.rollback(tmp);
				e.printStackTrace();
			}
			serverController.insertTransaction(transactionShowInfo);
			return new OperatorResult(false, "服务器异常,稍后再试");
		}
		return new OperatorResult(false, "不支持该类型操作");
	}

	// 同注册函数
	public OperatorResult processUsrLogin(Person person) {
		TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
		transactionShowInfo.setReUserIn(person.u_Id);
		transactionShowInfo.setReOpTypeIn(person.operator);
		transactionShowInfo.setReUsrTypeIn("普通用户");
		transactionShowInfo.setReOpTimeIn("数据库异常");
		transactionShowInfo.setReOpResIn("失败");
		try (Connection connection = ConnectionDB.getConnection()) {
			transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
			String query = "select U_ID from USERS where U_ID = ? and U_PASSWORD = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, person.u_Id);
			preparedStatement.setString(2, person.password);
			if (preparedStatement.executeQuery().next()) {
				transactionShowInfo.setReOpResIn("成功");
				serverController.insertTransaction(transactionShowInfo);
				return new OperatorResult(true, person.u_Id);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		serverController.insertTransaction(transactionShowInfo);
		return new OperatorResult(false, "登陆失败,检查用户名与密码");
	}

	// 同注册函数
	public OperatorResult processUsrModiPassword(Person person) {
		if (person instanceof PersonClient) {
			PersonClient personClient = (PersonClient) person;
			TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
			transactionShowInfo.setReUserIn(personClient.u_Id);
			transactionShowInfo.setReOpTypeIn(personClient.operator);
			transactionShowInfo.setReUsrTypeIn("普通用户");
			transactionShowInfo.setReOpTimeIn("数据库异常");
			transactionShowInfo.setReOpResIn("失败");
			// Connection tmp = null;
			try (Connection connection = ConnectionDB.getConnection()) {
				transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
				// tmp = connection;
				connection.setAutoCommit(false);
				String update = "update USERS set U_PASSWORD = ? where U_ID = ? and U_PHONE_NUM = ? and U_NAME = ?";
				PreparedStatement preparedStatement = connection.prepareStatement(update);
				preparedStatement.setString(1, personClient.password);
				preparedStatement.setString(2, personClient.u_Id);
				preparedStatement.setString(3, personClient.phoneNum);
				preparedStatement.setString(4, personClient.name);
				// 返回值表示成功修改的行数,大于0表示修改成功,等于0表示没有找到该用户
				int result = preparedStatement.executeUpdate();
				transactionShowInfo.setReOpResIn(result > 0 ? "成功" : "失败");
				connection.commit();

				if (result > 0) {
					serverController.insertTransaction(transactionShowInfo);
					return new OperatorResult(true, "修改成功");
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
				// ConnectionDB.rollback(tmp);
			}
			serverController.insertTransaction(transactionShowInfo);
			return new OperatorResult(false, "检查填写信息或者网络");
		}
		return new OperatorResult(false, "修改失败,检查数据传输");
	}

	public OperatorResult processUsrInfo(Person person) {
		TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
		transactionShowInfo.setReUserIn(person.u_Id);
		transactionShowInfo.setReOpTypeIn(person.operator);
		transactionShowInfo.setReUsrTypeIn("普通用户");
		transactionShowInfo.setReOpTimeIn("数据库异常");
		transactionShowInfo.setReOpResIn("失败");

		try (Connection connection = ConnectionDB.getConnection()) {
			transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
			String query = "select U_ID,U_NAME,U_PHONE_NUM,U_IS_VIP,U_RANK,U_BALANCE from USERS where U_ID = '"
					+ person.u_Id + "'";
			ResultSet resultSet = connection.createStatement().executeQuery(query);
			if (resultSet.next()) {
				UserInfo userInfo = new UserInfo(true, "查找成功");
				userInfo.personClient = new PersonClient();
				userInfo.personClient.u_Id = resultSet.getString("U_ID");
				userInfo.personClient.name = resultSet.getString("U_NAME");
				userInfo.personClient.phoneNum = resultSet.getString("U_PHONE_NUM");
				userInfo.personClient.ifVip = resultSet.getBoolean("U_IS_VIP");
				userInfo.personClient.rank = resultSet.getInt("U_RANK");
				userInfo.personClient.balance = resultSet.getBigDecimal("U_BALANCE").doubleValue();
				transactionShowInfo.setReOpResIn("成功");
				serverController.insertTransaction(transactionShowInfo);
				return userInfo;
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		serverController.insertTransaction(transactionShowInfo);
		return new OperatorResult(false, "数据库异常");
	}

	// 还未验证的函数
	public OperatorResult processEmployeeLogin(Person person) {
		TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
		transactionShowInfo.setReUserIn(person.u_Id);
		transactionShowInfo.setReOpTypeIn(person.operator);
		transactionShowInfo.setReUsrTypeIn("员工");
		transactionShowInfo.setReOpTimeIn("数据库异常");
		transactionShowInfo.setReOpResIn("失败");
		try (Connection connection = ConnectionDB.getConnection()) {
			transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
			String query = "select E_ID from EMPLOYEES where E_ID = ? and E_PASSWORD = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, person.u_Id);
			preparedStatement.setString(2, person.password);
			if (preparedStatement.executeQuery().next()) {
				transactionShowInfo.setReOpResIn("成功");
				serverController.insertTransaction(transactionShowInfo);
				return new OperatorResult(true, "登陆成功");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		serverController.insertTransaction(transactionShowInfo);
		return new OperatorResult(false, "登陆失败,检查用户名与密码和网络");
	}

	// 还未验证的函数
	public OperatorResult processQueryCar(QueryCar queryCar) {
		ArrayList<QueryCarInfo> queryCarInfos = new ArrayList<>();
		TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
		transactionShowInfo.setReUserIn(queryCar.u_Id);
		transactionShowInfo.setReUsrTypeIn("普通用户");
		transactionShowInfo.setReOpTypeIn("查询车辆信息");
		transactionShowInfo.setReOpTimeIn("数据库异常");
		transactionShowInfo.setReOpResIn("失败");
		try (Connection connection = ConnectionDB.getConnection()) {
			transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
			String query = "select C_ID,C_TYPE,C_PRICE,C_TIMEOUT from CARS where C_ID not in "
					+ "(select C_ID from BROKEN where IS_PREPARED = false) and C_IS_RENTED = false ";
			switch (queryCar.queryType) {
			// 用以扩展
			case "价格小于":
				query += "and C_PRICE < " + queryCar.price;
				break;
			case "价格大于":
				query += "and C_PRICE > " + queryCar.price;
				break;
			case "无条件":
			default:
				break;
			}
			ResultSet resultSet = connection.createStatement().executeQuery(query);
			while (resultSet.next()) {
				QueryCarInfo queryCarInfo = new QueryCarInfo();
				queryCarInfo.c_Id = resultSet.getString("C_ID");
				queryCarInfo.c_Type = resultSet.getString("C_TYPE");
				queryCarInfo.c_Price = resultSet.getBigDecimal("C_PRICE").doubleValue();
				queryCarInfo.c_TimeOutPrice = resultSet.getBigDecimal("C_TIMEOUT").doubleValue();
				queryCarInfos.add(queryCarInfo);
			}
			QueryCarDetails queryCarDetails = new QueryCarDetails();
			queryCarDetails.ifSuccess = true;
			queryCarDetails.descriptions = "获得数目:" + queryCarInfos.size();
			queryCarDetails.queryCarInfos = new QueryCarInfo[queryCarInfos.size()];
			queryCarInfos.toArray(queryCarDetails.queryCarInfos);
			transactionShowInfo.setReOpResIn("成功");
			serverController.insertTransaction(transactionShowInfo);
			return queryCarDetails;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		serverController.insertTransaction(transactionShowInfo);
		return new QueryCarDetails(false, "数据库异常");
	}

	// 还未验证的函数
	public OperatorResult processQueryDeal(QueryDeal queryDeal) {
		ArrayList<QueryDealInfo> queryDealInfos = new ArrayList<>();
		TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
		transactionShowInfo.setReUserIn(queryDeal.e_Id);
		transactionShowInfo.setReUsrTypeIn("员工");
		transactionShowInfo.setReOpTypeIn("查询交易记录");
		transactionShowInfo.setReOpTimeIn("数据库异常");
		transactionShowInfo.setReOpResIn("失败");

		try (Connection connection = ConnectionDB.getConnection()) {
			String query = "select RT_ID,RENT.U_ID,U_NAME,C_ID,OUT_TIME,BACK_TIME,PROCESS,TIME_INTERVAL "
					+ "from RENT,USERS where RENT.U_ID = USERS.U_ID and E_ID = " + queryDeal.e_Id;
			switch (queryDeal.queryType) {
			// 用以扩展
			case "未还车记录":
				query += " and BACK_TIME is null";
				break;
			case "无条件":
			default:
				break;
			}
			ResultSet resultSet = connection.createStatement().executeQuery(query);
			while (resultSet.next()) {
				QueryDealInfo queryDealInfo = new QueryDealInfo();
				queryDealInfo.rt_Id = resultSet.getString("RT_ID");
				queryDealInfo.u_Id = resultSet.getString("RENT.U_ID");
				queryDealInfo.u_Name = resultSet.getString("U_NAME");
				queryDealInfo.c_Id = resultSet.getString("C_ID");
				queryDealInfo.outTime = resultSet.getTimestamp("OUT_TIME").toString();
				Timestamp timestamp = resultSet.getTimestamp("BACK_TIME");
				queryDealInfo.backTime = timestamp == null ? "" : timestamp.toString();
				queryDealInfo.process = resultSet.getString("PROCESS");
				queryDealInfo.timeInterval = resultSet.getString("TIME_INTERVAL");
				queryDealInfos.add(queryDealInfo);
			}
			QueryDealDetails queryDealDetails = new QueryDealDetails();
			queryDealDetails.ifSuccess = true;
			queryDealDetails.descriptions = "获得的数目:" + queryDealInfos.size();
			queryDealDetails.queryDealInfos = new QueryDealInfo[queryDealInfos.size()];
			queryDealInfos.toArray(queryDealDetails.queryDealInfos);
			transactionShowInfo.setReOpResIn("成功");
			serverController.insertTransaction(transactionShowInfo);
			return queryDealDetails;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		serverController.insertTransaction(transactionShowInfo);
		return new OperatorResult(false, "数据库异常");
	}

	public OperatorResult processQueryHistory(QueryHistory queryHistory) {

		ArrayList<QueryHisBillInfo> queryHisBillInfos = new ArrayList<>();
		TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
		transactionShowInfo.setReUserIn(queryHistory.u_Id);
		transactionShowInfo.setReUsrTypeIn("普通用户");
		transactionShowInfo.setReOpTypeIn("查询历史记录");
		transactionShowInfo.setReOpTimeIn("数据库异常");
		transactionShowInfo.setReOpResIn("失败");
		try (Connection connection = ConnectionDB.getConnection()) {
			transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
			String query = "select RT_ID,RENT.C_ID,C_TYPE,EXPENSE,C_TIMEOUT,OUT_TIME,TIME_INTERVAL,E_NAME,PROGRESS	 "
					+ "from RENT,CARS,EMPLOYEES where RENT.C_ID = CARS.C_ID and RENT.E_ID = EMPLOYEES.E_ID and U_ID = '"
					+ queryHistory.u_Id + "' ";
			switch (queryHistory.queryType) {
			case "等待取车":
			case "正在使用":
			case "已完成":
				query += "and PROGRESS = '" + queryHistory.queryType + "'";
				break;
			case "无条件":
			default:
				break;
			}

			ResultSet resultSet = connection.createStatement().executeQuery(query);
			while (resultSet.next()) {
				QueryHisBillInfo queryHisBillInfo = new QueryHisBillInfo();
				queryHisBillInfo.rt_Id = resultSet.getString("RT_ID");
				queryHisBillInfo.c_Id = resultSet.getString("RENT.C_ID");
				queryHisBillInfo.c_Type = resultSet.getString("EXPENSE");
				queryHisBillInfo.outTimeExp = resultSet.getString("C_TIMEOUT");
				queryHisBillInfo.getCarTime = resultSet.getString("OUT_TIME");
				queryHisBillInfo.interval = resultSet.getString("TIME_INTERVAL");
				queryHisBillInfo.e_Name = resultSet.getString("E_NAME");
				queryHisBillInfo.progress = resultSet.getString("PROGRESS");
				queryHisBillInfos.add(queryHisBillInfo);
			}
			QueryHisBillDetails queryHisBillDetails = new QueryHisBillDetails();
			queryHisBillDetails.ifSuccess = true;
			queryHisBillDetails.descriptions = "获得数目:" + queryHisBillInfos.size();
			queryHisBillDetails.queryHisBillInfos = new QueryHisBillInfo[queryHisBillInfos.size()];
			queryHisBillInfos.toArray(queryHisBillDetails.queryHisBillInfos);
			transactionShowInfo.setReOpResIn("成功");
			serverController.insertTransaction(transactionShowInfo);
			return queryHisBillDetails;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		serverController.insertTransaction(transactionShowInfo);
		return new OperatorResult(false, "数据库异常");
	}

	public OperatorResult processRecharge(Person person) {
		if (person instanceof PersonClient) {
			PersonClient personClient = (PersonClient) person;
			TransactionShowInfo transactionShowInfo = new TransactionShowInfo();
			transactionShowInfo.setReUserIn(personClient.u_Id);
			transactionShowInfo.setReUsrTypeIn("普通用户");
			transactionShowInfo.setReOpTypeIn("充值");
			transactionShowInfo.setReOpTimeIn("数据库异常");
			transactionShowInfo.setReOpResIn("失败");
			try (Connection connection = ConnectionDB.getConnection()) {
				transactionShowInfo.setReOpTimeIn(ConnectionDB.getDBTime().toString());
				connection.setAutoCommit(false);

				String query = "select U_BALANCE,U_IS_VIP from USERS where U_ID = '" + personClient.u_Id + "'";
				ResultSet resultSet = connection.createStatement().executeQuery(query);
				double balance = 0;
				boolean ifVip = false;
				String description = "充值成功";
				if (resultSet.next()) {
					balance = resultSet.getBigDecimal("U_BALANCE").doubleValue();
					ifVip = resultSet.getBoolean("U_IS_VIP");
				} else {
					serverController.insertTransaction(transactionShowInfo);
					return new OperatorResult(false, "数据库异常");
				}
				if (personClient.ifVip) {
					if (balance + personClient.balance < 100 && !ifVip) {
						serverController.insertTransaction(transactionShowInfo);
						return new OperatorResult(false, "余额不足,充值失败");
					} else if (!ifVip) {
						balance = balance + personClient.balance - 100;
						ifVip = true;
						description = "充值成功,恭喜您成为会员";
					} else {
						balance += personClient.balance;
						description = "充值成功，但您已经是会员";
					}
				} else {
					balance += personClient.balance;
				}

				String update = "update USERS set U_BALANCE = " + balance + ",U_IS_VIP = " + ifVip + " where U_ID = '"
						+ personClient.u_Id + "' and U_PASSWORD = '" + personClient.password + "' and U_PHONE_NUM = '"
						+ personClient.phoneNum + "'";
				int result = connection.createStatement().executeUpdate(update);
				connection.commit();
				if (result > 0) {
					transactionShowInfo.setReOpResIn("成功");
					serverController.insertTransaction(transactionShowInfo);
					return new OperatorResult(true, description);
				} else {
					transactionShowInfo.setReOpResIn("失败");
					serverController.insertTransaction(transactionShowInfo);
					return new OperatorResult(true, "请确认信息");
				}

			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			serverController.insertTransaction(transactionShowInfo);
			return new OperatorResult(false, "数据库异常");
		}
		return new OperatorResult(false, "不支持该类型操作");
	}
}
