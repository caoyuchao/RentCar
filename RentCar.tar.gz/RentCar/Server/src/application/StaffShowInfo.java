package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

//员工表格一行
//对应的类的封装
public class StaffShowInfo {

	private StringProperty StEidIn;

	private StringProperty StNameIn;

	private StringProperty StNumIn;

	private StringProperty StTotalIn;

	public void setStEidIn(String value) {
		StEidInProperty().set(value);
	}

	public String getStEidIn() {
		return StEidInProperty().get();
	}

	public StringProperty StEidInProperty() {
		if (StEidIn == null) {
			StEidIn = new SimpleStringProperty(this, "StEidIn");
		}
		return StEidIn;
	}

	public void setStNameIn(String value) {
		StNameInProperty().set(value);
	}

	public String getStNameIn() {
		return StNameInProperty().get();
	}

	public StringProperty StNameInProperty() {
		if (StNameIn == null) {
			StNameIn = new SimpleStringProperty(this, "StNameIn");
		}
		return StNameIn;
	}

	public void setStNumIn(String value) {
		StNumInProperty().set(value);
	}

	public String getStNumIn() {
		return StNumInProperty().get();
	}

	public StringProperty StNumInProperty() {
		if (StNumIn == null) {
			StNumIn = new SimpleStringProperty(this, "StNumIn");
		}
		return StNumIn;
	}

	public void setStTotalIn(String value) {
		StTotalInProperty().set(value);
	}

	public String getStTotalIn() {
		return StTotalInProperty().get();
	}

	public StringProperty StTotalInProperty() {
		if (StTotalIn == null) {
			StTotalIn = new SimpleStringProperty(this, "StTotalIn");
		}
		return StTotalIn;
	}
}
