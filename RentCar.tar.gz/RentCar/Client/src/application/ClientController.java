package application;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JOptionPane;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.stage.Stage;

public class ClientController implements ProcessObjectFromServer {
	@FXML
	private Tab tabCar;
	@FXML
	private ComboBox<String> carCbQuery;
	@FXML
	private TextField carTfCondition;
	@FXML
	private Button carBtUpdate;
	@FXML
	private TableView<RentCarShowInfo> carTable;
	@FXML
	private TableColumn<RentCarShowInfo, String> carCid;
	@FXML
	private TableColumn<RentCarShowInfo, String> carCType;
	@FXML
	private TableColumn<RentCarShowInfo, String> carPrice;
	@FXML
	private TableColumn<RentCarShowInfo, String> carPriceOut;
	@FXML
	private TableColumn<RentCarShowInfo, String> carDescription;
	@FXML
	private Tab tabHis;
	@FXML
	private ComboBox<String> hisCbQuery;
	@FXML
	private TextField hisTfCondition;
	@FXML
	private Button hisBtUpdate;
	@FXML
	private TableView<HistoryShowInfo> hisTable;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisRt_Id;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisCid;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisCType;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisExp;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisExpOut;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisGetCarTime;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisCarIntre;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisEmploy;
	@FXML
	private TableColumn<HistoryShowInfo, String> hisProc;
	@FXML
	private Tab tabDes;
	@FXML
	private TextField tfPho;
	@FXML
	private TextField tfBill;
	@FXML
	private Button btCommot;
	@FXML
	private TextField tfId;
	@FXML
	private PasswordField tfPsd;
	@FXML
	private Slider sliderRank;
	@FXML
	private Label lbId;
	@FXML
	private Label lbName;
	@FXML
	private Label lbPhone;
	@FXML
	private Label lbIfVip;
	@FXML
	private Label lbBalance;
	@FXML
	private CheckBox chbIfVip;

	private Stage stage;
	private Socket socket;
	private ClientThread thread;
	private String id;

	public void setId(String id) {
		this.id = id;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public void init() throws IOException {
		tfId.setText(id);
		socket = new Socket(Main.IP, Main.PORT);
		thread = new ClientThread(socket, this);
		stage.setOnCloseRequest((e) -> {
			// 窗口关闭时退出线程并尝试关闭socket
			thread.ifExit = true;
			tryCloseSocket(socket);
		});
		thread.start();

		carCid.setCellValueFactory(new PropertyValueFactory<>("carCidIn"));
		carCType.setCellValueFactory(new PropertyValueFactory<>("carCTypeIn"));
		carPrice.setCellValueFactory(new PropertyValueFactory<>("carPriceIn"));
		carPriceOut.setCellValueFactory(new PropertyValueFactory<>("carPriceOutIn"));
		carDescription.setCellValueFactory(new PropertyValueFactory<>("carDescriptionIn"));

		hisRt_Id.setCellValueFactory(new PropertyValueFactory<>("hisRt_IdIn"));
		hisCid.setCellValueFactory(new PropertyValueFactory<>("hisCidIn"));
		hisCType.setCellValueFactory(new PropertyValueFactory<>("hisCTypeIn"));
		hisExp.setCellValueFactory(new PropertyValueFactory<>("hisExpIn"));
		hisExpOut.setCellValueFactory(new PropertyValueFactory<>("hisExpOutIn"));

		hisGetCarTime.setCellValueFactory(new PropertyValueFactory<>("hisGetCarTimeIn"));
		hisCarIntre.setCellValueFactory(new PropertyValueFactory<>("hisCarIntreIn"));
		hisEmploy.setCellValueFactory(new PropertyValueFactory<>("hisEmployIn"));
		hisProc.setCellValueFactory(new PropertyValueFactory<>("hisProcIn"));

		carCbQuery.getItems().addAll(new ArrayList<>(Arrays.asList("价格大于", "价格小于", "无条件")));
		hisCbQuery.getItems().addAll(new ArrayList<>(Arrays.asList("等待取车", "正在使用", "已完成", "无条件")));

		carTable.setRowFactory((param) -> {
			return new TableRowControl(carTable, id);
		});
		// carBtUpdateClicked(null);
	}

	// Event Listener on Button[#carBtUpdate].onAction
	@FXML
	public void carBtUpdateClicked(ActionEvent event) {
		if (null == socket) {
			return;
		}
		String cbSelect = carCbQuery.getValue();
		String condition = carTfCondition.getText().trim();
		double price = 0;
		if (null == cbSelect) {
			cbSelect = "无条件";
		}

		if (!cbSelect.equals("无条件")) {
			try {
				price = Double.parseDouble(condition);
			} catch (NumberFormatException e) {
				// 服务器端并没有进行安全检查
				JOptionPane.showMessageDialog(null, "条件异常");
				return;
			}
		}
		pushToServer(new QueryCar(id, cbSelect, price));
	}

	// Event Listener on Button[#hisBtUpdate].onAction
	@FXML
	public void hisBtUpdateClicked(ActionEvent event) {
		String cbSelect = hisCbQuery.getValue();
		// 待扩展功能时使用
		// String condition = carTfCondition.getText().trim();
		if (null == cbSelect) {
			cbSelect = "无条件";
		}
		pushToServer(new QueryHistory(id, cbSelect));
	}

	// Event Listener on Button[#btCommot].onAction
	@FXML
	public void btCommitClicked(ActionEvent event) {

		String password = tfPsd.getText().trim();
		if (0 == password.length()) {
			JOptionPane.showMessageDialog(null, "密码不为空");
			return;
		}
		String phone = tfPho.getText().trim();
		if (0 == phone.length()) {
			JOptionPane.showMessageDialog(null, "手机号不为空");
			return;
		}
		double balance = 0;
		String bal = tfBill.getText().trim();

		if (!chbIfVip.isSelected() && 0 == bal.length()) {
			JOptionPane.showMessageDialog(null, "选择充值余额或者会员");
		}
		try {
			if (0 != bal.length()) {
				balance = Double.parseDouble(bal);
			}
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "请检查充值金额输入是否合法");
			return;
		}
		PersonClient personClient = new PersonClient(id, password, "用户充值", "", phone);
		personClient.ifVip = chbIfVip.isSelected();
		personClient.balance = balance;
		pushToServer(personClient);
	}

	@FXML
	public void btGetInfoClicked(Event event) {
		pushToServer(new Person(id, "", "用户信息查询"));
	}

	@Override
	public void processFromServer(Object object) {
		if (object instanceof UserInfo) {
			UserInfo userInfo = (UserInfo) object;
			if (userInfo.ifSuccess) {
				Platform.runLater(() -> {
					lbId.setText(id);
					lbName.setText(userInfo.personClient.name);
					lbPhone.setText(userInfo.personClient.phoneNum);
					lbIfVip.setText(userInfo.personClient.ifVip ? "会员" : "普通用户");
					sliderRank.setValue(userInfo.personClient.rank);
					lbBalance.setText(userInfo.personClient.balance + "");
				});
			} else {
				JOptionPane.showMessageDialog(null, userInfo.descriptions);
			}
		} else if (object instanceof QueryCarDetails) {
			QueryCarDetails queryCarDetails = (QueryCarDetails) object;
			if (queryCarDetails.ifSuccess) {
				ObservableList<RentCarShowInfo> observableList = FXCollections.observableArrayList();
				for (int i = 0; i < queryCarDetails.queryCarInfos.length; i++) {
					RentCarShowInfo rentCarShowInfo = new RentCarShowInfo();
					rentCarShowInfo.setcarCidIn(queryCarDetails.queryCarInfos[i].c_Id);
					rentCarShowInfo.setcarCTypeIn(queryCarDetails.queryCarInfos[i].c_Type);
					rentCarShowInfo.setcarPriceIn(queryCarDetails.queryCarInfos[i].c_Price + "");
					rentCarShowInfo.setcarPriceOutIn(queryCarDetails.queryCarInfos[i].c_TimeOutPrice + "");
					rentCarShowInfo.setcarDescriptionIn(queryCarDetails.queryCarInfos[i].c_description);
					observableList.add(rentCarShowInfo);
				}
				Platform.runLater(() -> {
					carTable.setItems(observableList);
				});
			} else {
				JOptionPane.showMessageDialog(null, queryCarDetails.descriptions);
			}
		} else if (object instanceof QueryHisBillDetails) {
			QueryHisBillDetails queryHisBillDetails = (QueryHisBillDetails) object;
			if (queryHisBillDetails.ifSuccess) {
				ObservableList<HistoryShowInfo> observableList = FXCollections.observableArrayList();
				for (int i = 0; i < queryHisBillDetails.queryHisBillInfos.length; i++) {
					HistoryShowInfo historyShowInfo = new HistoryShowInfo();
					historyShowInfo.sethisRt_IdIn(queryHisBillDetails.queryHisBillInfos[i].rt_Id);
					historyShowInfo.sethisCidIn(queryHisBillDetails.queryHisBillInfos[i].c_Id);
					historyShowInfo.sethisCTypeIn(queryHisBillDetails.queryHisBillInfos[i].c_Type);
					historyShowInfo.sethisExpIn(queryHisBillDetails.queryHisBillInfos[i].expense);
					historyShowInfo.sethisExpOutIn(queryHisBillDetails.queryHisBillInfos[i].outTimeExp);
					historyShowInfo.sethisGetCarTimeIn(queryHisBillDetails.queryHisBillInfos[i].getCarTime);
					historyShowInfo.sethisCarIntreIn(queryHisBillDetails.queryHisBillInfos[i].interval);
					historyShowInfo.sethisEmployIn(queryHisBillDetails.queryHisBillInfos[i].e_Name);
					historyShowInfo.sethisProcIn(queryHisBillDetails.queryHisBillInfos[i].progress);
					observableList.add(historyShowInfo);
				}
				Platform.runLater(() -> {
					hisTable.setItems(observableList);
				});
			} else {
				JOptionPane.showMessageDialog(null, queryHisBillDetails.descriptions);
			}
		} else if (object instanceof OperatorResult) {
			OperatorResult operatorResult = (OperatorResult) object;
			JOptionPane.showMessageDialog(null, operatorResult.descriptions);
		} else {
			JOptionPane.showMessageDialog(null, "检查数据库异常");
		}
	}

	private void tryCloseSocket(Socket socket) {
		try {
			thread.ifExit = true;
			if (!socket.isClosed()) {
				socket.close();
			}
		} catch (IOException ex) {

		}
	}

	public void pushToServer(Object object) {
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectOutputStream.writeObject(object);
			objectOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

class TableRowControl extends TableRow<RentCarShowInfo> {
	public TableRowControl(TableView<RentCarShowInfo> carT, String id) {
		this.setOnMouseClicked((e) -> {
			if (e.getButton().equals(MouseButton.PRIMARY) && e.getClickCount() == 2
					&& this.getIndex() < carT.getItems().size()) {
				try {
					FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("RentCar.fxml"));
					Parent root = fxmlLoader.load();
					RentCarController controller = fxmlLoader.getController();
					Stage st = new Stage();
					st.setResizable(false);
					controller.setStage(st);
					controller.setRentCarShowInfo(carT.getItems().get(getIndex()));
					controller.setId(id);
					controller.init();
					st.setTitle("My Application");
					st.setScene(new Scene(root));
					st.show();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		});
	}
}
