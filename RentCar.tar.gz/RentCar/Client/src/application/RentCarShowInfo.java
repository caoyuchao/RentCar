package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class RentCarShowInfo {

	private StringProperty carCidIn;

	private StringProperty carCTypeIn;

	private StringProperty carPriceIn;

	private StringProperty carPriceOutIn;

	private StringProperty carDescriptionIn;

	public void setcarCidIn(String value) {
		carCidInProperty().set(value);
	}

	public String getcarCidIn() {
		return carCidInProperty().get();
	}

	public StringProperty carCidInProperty() {
		if (carCidIn == null) {
			carCidIn = new SimpleStringProperty(this, "carCidIn");
		}
		return carCidIn;
	}

	public void setcarCTypeIn(String value) {
		carCTypeInProperty().set(value);
	}

	public String getcarCTypeIn() {
		return carCTypeInProperty().get();
	}

	public StringProperty carCTypeInProperty() {
		if (carCTypeIn == null) {
			carCTypeIn = new SimpleStringProperty(this, "carCTypeIn");
		}
		return carCTypeIn;
	}

	public void setcarPriceIn(String value) {
		carPriceInProperty().set(value);
	}

	public String getcarPriceIn() {
		return carPriceInProperty().get();
	}

	public StringProperty carPriceInProperty() {
		if (carPriceIn == null) {
			carPriceIn = new SimpleStringProperty(this, "carPriceIn");
		}
		return carPriceIn;
	}

	public void setcarPriceOutIn(String value) {
		carPriceOutInProperty().set(value);
	}

	public String getcarPriceOutIn() {
		return carPriceOutInProperty().get();
	}

	public StringProperty carPriceOutInProperty() {
		if (carPriceOutIn == null) {
			carPriceOutIn = new SimpleStringProperty(this, "carPriceOutIn");
		}
		return carPriceOutIn;
	}

	public void setcarDescriptionIn(String value) {
		carDescriptionInProperty().set(value);
	}

	public String getcarDescriptionIn() {
		return carDescriptionInProperty().get();
	}

	public StringProperty carDescriptionInProperty() {
		if (carDescriptionIn == null) {
			carDescriptionIn = new SimpleStringProperty(this, "carDescriptionIn");
		}
		return carDescriptionIn;
	}
}
