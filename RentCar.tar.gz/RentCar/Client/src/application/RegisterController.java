package application;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegisterController implements ProcessObjectFromServer {
	@FXML
	private TextField tfId;
	@FXML
	private PasswordField tfPsd;
	@FXML
	private PasswordField tfPsdConf;
	@FXML
	private TextField tfBill;
	@FXML
	private Button btCommit;
	@FXML
	private Button btCancel;
	@FXML
	private TextField tfPhone;
	@FXML
	private CheckBox chbVip;
	@FXML
	private TextField tfName;

	private Stage stage;
	private Socket socket;
	private ClientThread thread;

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	// 初始化函数,类似GetPsdController中的init函数
	public void init() throws IOException {
		socket = new Socket(Main.IP, Main.PORT);
		thread = new ClientThread(socket, this);
		stage.setOnCloseRequest((e) -> {
			thread.ifExit = true;
			tryCloseSocket(socket);
		});
		thread.start();
	}

	// Event Listener on Button[#btCommit].onAction
	@FXML
	public void btCommitClicked(ActionEvent event) {
		// 安全检查
		String id = tfId.getText().trim();
		if (0 == id.length()) {
			JOptionPane.showMessageDialog(null, "身份证号不为空");
			return;
		}
		if (18 != id.length()) {
			JOptionPane.showMessageDialog(null, "身份证号是否填写完整");
			return;
		}
		String name = tfName.getText().trim();
		if (0 == name.length()) {
			JOptionPane.showMessageDialog(null, "姓名不为空");
			return;
		}
		String password = tfPsd.getText().trim();
		if (0 == password.length()) {
			JOptionPane.showMessageDialog(null, "密码不为空");
			return;
		}
		String passwordConf = tfPsdConf.getText().trim();
		if (0 == passwordConf.length()) {
			JOptionPane.showMessageDialog(null, "确认密码不为空");
			return;
		}

		if (!password.equals(passwordConf)) {
			JOptionPane.showMessageDialog(null, "密码不一致");
			return;
		}

		String phone = tfPhone.getText().trim();
		if (0 == phone.length()) {
			JOptionPane.showMessageDialog(null, "手机号不为空");
			return;
		}

		boolean ifVip = chbVip.isSelected();
		String bill = tfBill.getText().trim();
		double dbill = 0;

		if (0 != bill.length()) {
			dbill = Double.parseDouble(bill);
			if (dbill < 0) {
				dbill = 0;
			}
		}
		// VIP扣除一百元
		if (ifVip) {
			dbill -= 100;
			if (dbill < 0) {
				JOptionPane.showMessageDialog(null, "金额不足");
			}
		}
		if (ifVip) {

		}
		PersonClient personClient = new PersonClient();
		personClient.u_Id = id;
		personClient.password = password;
		personClient.name = name;
		personClient.operator = "用户注册";
		personClient.phoneNum = phone;
		personClient.ifVip = ifVip;
		personClient.balance = dbill;
		personClient.rank = 0;
		pushToServer(personClient);
	}

	public void pushToServer(Object object) {
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectOutputStream.writeObject(object);
			objectOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Event Listener on Button[#btCancel].onAction
	@FXML
	public void btCancelClicked(ActionEvent event) {
		tryCloseSocket(socket);
		stage.close();
	}

	@Override
	public void processFromServer(Object object) {
		if (object instanceof OperatorResult) {
			OperatorResult operatorResult = (OperatorResult) object;
			JOptionPane.showMessageDialog(null, operatorResult.descriptions);
		} else {
			JOptionPane.showMessageDialog(null, "检查网络是否正常");
		}
	}

	private void tryCloseSocket(Socket socket) {
		try {
			thread.ifExit = true;
			if (!socket.isClosed()) {
				socket.close();
			}
		} catch (IOException ex) {

		}
	}
}
