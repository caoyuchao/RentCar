package application;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class GetPsdController implements ProcessObjectFromServer {
	@FXML
	private TextField tfId;
	@FXML
	private TextField tfName;
	@FXML
	private PasswordField tfPsd;
	@FXML
	private TextField tfPhone;
	@FXML
	private Button btCommit;
	@FXML
	private Button btCancel;

	private Stage stage;
	private Socket socket;
	private ClientThread thread;

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	// 初始化函数,创建套接字,增加监听事件
	public void init() throws IOException {
		socket = new Socket(Main.IP, Main.PORT);
		thread = new ClientThread(socket, this);
		stage.setOnCloseRequest((e) -> {
			// 窗口关闭时退出线程并尝试关闭socket
			tryCloseSocket(socket);
		});
		thread.start();
	}

	// Event Listener on Button[#btCommit].onAction
	@FXML
	public void btCommitClicked(ActionEvent event) {
		// 安全检查
		String id = tfId.getText().trim();
		if (0 == id.length()) {
			JOptionPane.showMessageDialog(null, "请输入身份证号");
			return;
		}

		if (18 != id.length()) {
			JOptionPane.showMessageDialog(null, "请检查身份证号是否正确");
			return;
		}

		String password = tfPsd.getText().trim();
		if (0 == password.length()) {
			JOptionPane.showMessageDialog(null, "请输入密码");
			return;
		}
		String name = tfName.getText().trim();
		if (0 == name.length()) {
			JOptionPane.showMessageDialog(null, "请输入姓名");
			return;
		}
		String phone = tfPhone.getText().trim();
		if (0 == phone.length()) {
			JOptionPane.showMessageDialog(null, "请输入手机号");
			return;
		}

		PersonClient personClient = new PersonClient(id, password, "用户找回密码", name, phone);
		// 将构造的对象发送到服务器
		pushToServer(personClient);
	}

	// Event Listener on Button[#btCancel].onAction
	@FXML
	public void btCancelClicked(ActionEvent event) {
		tryCloseSocket(socket);
		stage.close();
	}

	@Override
	public void processFromServer(Object object) {
		if (object instanceof OperatorResult) {
			OperatorResult operatorResult = (OperatorResult) object;
			// 将服务器的处理结果进行显示
			JOptionPane.showMessageDialog(null, operatorResult.descriptions);
		} else {
			JOptionPane.showMessageDialog(null, "检查网络是否正常");
		}
	}

	public void pushToServer(Object object) {
		try {
			// 根据套接字将对象写到服务器
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectOutputStream.writeObject(object);
			objectOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void tryCloseSocket(Socket socket) {
		try {
			thread.ifExit = true;
			if (!socket.isClosed()) {
				socket.close();
			}
		} catch (IOException ex) {

		}
	}

}
