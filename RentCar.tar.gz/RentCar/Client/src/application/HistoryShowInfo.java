package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class HistoryShowInfo {

	private StringProperty hisRt_IdIn;

	private StringProperty hisCidIn;

	private StringProperty hisCTypeIn;

	private StringProperty hisExpIn;

	private StringProperty hisExpOutIn;

	private StringProperty hisGetCarTimeIn;

	private StringProperty hisCarIntreIn;

	private StringProperty hisEmployIn;

	private StringProperty hisProcIn;

	public void sethisRt_IdIn(String value) {
		hisRt_IdInProperty().set(value);
	}

	public String gethisRt_IdIn() {
		return hisRt_IdInProperty().get();
	}

	public StringProperty hisRt_IdInProperty() {
		if (hisRt_IdIn == null) {
			hisRt_IdIn = new SimpleStringProperty(this, "hisRt_IdIn");
		}
		return hisRt_IdIn;
	}

	public void sethisCidIn(String value) {
		hisCidInProperty().set(value);
	}

	public String gethisCidIn() {
		return hisCidInProperty().get();
	}

	public StringProperty hisCidInProperty() {
		if (hisCidIn == null) {
			hisCidIn = new SimpleStringProperty(this, "hisCidIn");
		}
		return hisCidIn;
	}

	public void sethisCTypeIn(String value) {
		hisCTypeInProperty().set(value);
	}

	public String gethisCTypeIn() {
		return hisCTypeInProperty().get();
	}

	public StringProperty hisCTypeInProperty() {
		if (hisCTypeIn == null) {
			hisCTypeIn = new SimpleStringProperty(this, "hisCTypeIn");
		}
		return hisCTypeIn;
	}

	public void sethisExpIn(String value) {
		hisExpInProperty().set(value);
	}

	public String gethisExpIn() {
		return hisExpInProperty().get();
	}

	public StringProperty hisExpInProperty() {
		if (hisExpIn == null) {
			hisExpIn = new SimpleStringProperty(this, "hisExpIn");
		}
		return hisExpIn;
	}

	public void sethisExpOutIn(String value) {
		hisExpOutInProperty().set(value);
	}

	public String gethisExpOutIn() {
		return hisExpOutInProperty().get();
	}

	public StringProperty hisExpOutInProperty() {
		if (hisExpOutIn == null) {
			hisExpOutIn = new SimpleStringProperty(this, "hisExpOutIn");
		}
		return hisExpOutIn;
	}

	public void sethisGetCarTimeIn(String value) {
		hisGetCarTimeInProperty().set(value);
	}

	public String gethisGetCarTimeIn() {
		return hisGetCarTimeInProperty().get();
	}

	public StringProperty hisGetCarTimeInProperty() {
		if (hisGetCarTimeIn == null) {
			hisGetCarTimeIn = new SimpleStringProperty(this, "hisGetCarTimeIn");
		}
		return hisGetCarTimeIn;
	}

	public void sethisCarIntreIn(String value) {
		hisCarIntreInProperty().set(value);
	}

	public String gethisCarIntreIn() {
		return hisCarIntreInProperty().get();
	}

	public StringProperty hisCarIntreInProperty() {
		if (hisCarIntreIn == null) {
			hisCarIntreIn = new SimpleStringProperty(this, "hisCarIntreIn");
		}
		return hisCarIntreIn;
	}

	public void sethisEmployIn(String value) {
		hisEmployInProperty().set(value);
	}

	public String gethisEmployIn() {
		return hisEmployInProperty().get();
	}

	public StringProperty hisEmployInProperty() {
		if (hisEmployIn == null) {
			hisEmployIn = new SimpleStringProperty(this, "hisEmployIn");
		}
		return hisEmployIn;
	}

	public void sethisProcIn(String value) {
		hisProcInProperty().set(value);
	}

	public String gethisProcIn() {
		return hisProcInProperty().get();
	}

	public StringProperty hisProcInProperty() {
		if (hisProcIn == null) {
			hisProcIn = new SimpleStringProperty(this, "hisProcIn");
		}
		return hisProcIn;
	}
}
