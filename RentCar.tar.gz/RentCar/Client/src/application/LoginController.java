package application;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JOptionPane;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements ProcessObjectFromServer {

	@FXML
	private TextField tfId;
	@FXML
	private PasswordField tfPsd;
	@FXML
	private Button btLogin;
	@FXML
	private Button btRegister;
	@FXML
	private Button btGetPsd;

	private Stage stage;
	private Socket socket;

	private ClientThread thread;

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	// 初始化,同GetPsdController中的init函数
	public void init() throws IOException {
		socket = new Socket(Main.IP, Main.PORT);
		thread = new ClientThread(socket, this);
		stage.setOnCloseRequest((e) -> {
			tryCloseSocket(socket);
		});
		thread.start();
	}

	// Event Listener on Button[#btLogin].onAction
	@FXML
	public void btLoginClicked(ActionEvent event) {
		String id = tfId.getText().trim();
		if (null == id) {
			JOptionPane.showMessageDialog(null, "请输入身份证号登陆");
			return;
		}
		if (18 != id.length()) {
			JOptionPane.showMessageDialog(null, "身份证号错误");
			return;
		}
		String password = tfPsd.getText().trim();
		if (null == password) {
			JOptionPane.showMessageDialog(null, "请输入密码");
			return;
		}
		Person person = new Person(id, password, "用户登陆");
		pushToServer(person);
	}

	// Event Listener on Button[#btRegister].onAction
	@FXML
	public void btRegisterClicked(ActionEvent event) {
		try {
			// 加载注册界面
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Register.fxml"));
			Parent root = fxmlLoader.load();
			RegisterController controller = fxmlLoader.getController();
			Stage st = new Stage();
			st.setResizable(false);
			controller.setStage(st);
			controller.init();
			st.setTitle("My Application");
			st.setScene(new Scene(root));
			st.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Event Listener on Button[#btGetPsd].onAction
	@FXML
	public void btGetPsdClicked(ActionEvent event) {
		try {
			// 加载找回密码界面
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("GetPsd.fxml"));
			Parent root = fxmlLoader.load();
			GetPsdController controller = fxmlLoader.getController();
			Stage st = new Stage();
			st.setResizable(false);
			controller.setStage(st);
			controller.init();
			st.setTitle("My Application");
			st.setScene(new Scene(root));
			st.show();
			tryCloseSocket(socket);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void processFromServer(Object object) {
		if (object instanceof OperatorResult) {
			OperatorResult operatorResult = (OperatorResult) object;
			if (operatorResult.ifSuccess) {
				tryCloseSocket(socket);
				Platform.runLater(() -> {
					try {
						FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Client.fxml"));
						Parent root = fxmlLoader.load();
						ClientController controller = fxmlLoader.getController();
						Stage st = new Stage();
						st.setResizable(false);
						controller.setStage(st);
						controller.setId(operatorResult.descriptions);
						controller.init();
						st.setTitle("My Application");
						st.setScene(new Scene(root));
						st.show();
						stage.close();
					} catch (IOException e) {
					}
				});
			} else {
				JOptionPane.showMessageDialog(null, operatorResult.descriptions);
			}
		} else {
			JOptionPane.showMessageDialog(null, "检查网络是否正常");
		}
	}

	public void pushToServer(Object object) {
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectOutputStream.writeObject(object);
			objectOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void tryCloseSocket(Socket socket) {
		try {
			thread.ifExit = true;
			if (!socket.isClosed()) {
				socket.close();
			}
		} catch (IOException ex) {

		}
	}
}
