package application;

public interface ProcessObjectFromServer {
	public void processFromServer(Object object);
}
