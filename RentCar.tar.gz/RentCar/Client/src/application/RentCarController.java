package application;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RentCarController implements ProcessObjectFromServer {
	@FXML
	private TextField tfCId;
	@FXML
	private Button btCommit;
	@FXML
	private ComboBox<Integer> cbInter;
	@FXML
	private DatePicker dtTime;
	@FXML
	private TextField tfCType;
	@FXML
	private TextField tfPrice;
	@FXML
	private TextField tfPriceOut;

	private Stage stage;
	private Socket socket;
	private ClientThread thread;
	private String id;
	private final int INTERVAL = 61;// 租车时间范围1-60天

	private RentCarShowInfo rentCarShowInfo;

	public void setRentCarShowInfo(RentCarShowInfo rentCarShowInfo) {
		this.rentCarShowInfo = rentCarShowInfo;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public void setId(String id) {
		this.id = id;
	}

	void init() throws IOException {
		socket = new Socket(Main.IP, Main.PORT);
		thread = new ClientThread(socket, this);
		stage.setOnCloseRequest((e) -> {
			// 窗口关闭时退出线程并尝试关闭socket
			thread.ifExit = true;
			tryCloseSocket(socket);
		});
		thread.start();

		tfCId.setText(rentCarShowInfo.getcarCidIn());
		tfCType.setText(rentCarShowInfo.getcarCTypeIn());
		tfPrice.setText(rentCarShowInfo.getcarPriceIn());
		tfPriceOut.setText(rentCarShowInfo.getcarPriceOutIn());

		for (int i = 1; i < INTERVAL; i++) {
			cbInter.getItems().add(i);
		}
	}

	// Event Listener on Button[#btCommit].onAction
	@FXML
	public void btCommitClicked(ActionEvent event) {
		System.out.println("OK");
	}

	@Override
	public void processFromServer(Object object) {

	}

	private void tryCloseSocket(Socket socket) {
		try {
			thread.ifExit = true;
			if (!socket.isClosed()) {
				socket.close();
			}
		} catch (IOException ex) {

		}
	}

	public void pushToServer(Object object) {
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectOutputStream.writeObject(object);
			objectOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
