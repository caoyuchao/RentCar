package application;

import java.io.ObjectInputStream;
import java.net.Socket;

public class ClientThread extends Thread {
	private Socket socket = null;// 和本线程相关的Socket
	private final ProcessObjectFromServer controller;
	public boolean ifExit = false;

	public ClientThread(Socket socket, ProcessObjectFromServer controller) {
		this.controller = controller;
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			while (!ifExit) {
				// 处理读到的对象
				processFromServer(new ObjectInputStream(socket.getInputStream()).readObject());
			}
		} catch (Exception e) {
			// e.printStackTrace();
			ifExit = true;
		}
	}

	public void processFromServer(Object object) {
		controller.processFromServer(object);
	}
}
